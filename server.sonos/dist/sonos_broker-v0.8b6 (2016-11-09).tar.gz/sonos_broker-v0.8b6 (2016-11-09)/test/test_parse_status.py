import requests

url = "http://192.168.178.40:1400/status/ifconfig"
try:

    wifi_request = requests.get(url, timeout=5)
    if wifi_request.status_code is not 200:
        print(wifi_request.respose)
        raise Exception("Wrong status code. Expect 200, got {code}!".format(code=wifi_request.status_code))

    if 'ath0' in wifi_request.text:
        print('wfif on')
    else:
        print('wifi off')

    print(wifi_request.text)

except requests.ConnectionError:
    print("Could not connect to {url}".format(url=url))
except Exception as err:
    print(err)
